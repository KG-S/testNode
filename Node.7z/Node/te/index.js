const express = require("express");
const app = express();


app.get("/", function(req, res){
    res.sendFile(__dirname+"/html/index.html");
});
app.get("/sobre", function(req, res){
    res.send("minha pagina sobre");
});
app.get('/blog/:nome', function(req, res){
    res.send(req.params);
});



app.listen(10000, function(){
    console.log("servidor rodando na url http://localhost:10000");
})